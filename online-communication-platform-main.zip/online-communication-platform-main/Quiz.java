public class Quiz
{

private int marks;


 
public void SetMarks(int mr)
{
	
marks=mr;

}	

public void showMarks()
{
System.out.println("\t\t\t\t\t\t\t\t_________________________________________");
System.out.println("\t\t\t\t\t\t\t\t|                                         |");	
System.out.println("\t\t\t\t\t\t\t\t            Your marks : "+marks    );
System.out.println("\t\t\t\t\t\t\t\t|                                         |");	
System.out.println("\t\t\t\t\t\t\t\t|_________________________________________|");	
}


}	